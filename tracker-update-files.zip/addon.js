window.cbseAddon=function(c){
const {syllabus,getS,save,esc}=c,$=q=>document.querySelector(q),$$=q=>[...document.querySelectorAll(q)];
const uid=(window.Clerk&&Clerk.user&&Clerk.user.id)||'guest',LK='cbseTests_'+uid;
let tests=[];try{tests=JSON.parse(localStorage.getItem(LK)||'[]')}catch(e){}
let draft={};const subs=Object.keys(syllabus);
const K=(s,i)=>s+'::'+i,isDone=(s,i)=>!!getS().done[K(s,i)];
const SHORT={Mathematics:'Maths','Social Science':'SST','Hindi Course B':'Hindi','Information Technology':'IT'};
const fmt=d=>new Date(d+'T00:00:00').toLocaleDateString('en-IN',{weekday:'short',day:'numeric',month:'short',year:'numeric'});
const left=d=>{const t=new Date();t.setHours(0,0,0,0);return Math.round((new Date(d+'T00:00:00')-t)/864e5)};
function renderGraph(){
 const W=620,n=subs.length,slot=(W-34)/n,bw=Math.min(52,slot-22);let g='<defs><linearGradient id="gbar" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#635bff"/><stop offset="1" stop-color="#c14df0"/></linearGradient></defs>',D=0,T=0;
 [0,50,100].forEach(v=>{const y=190-v*1.5;g+=`<line x1="34" x2="${W}" y1="${y}" y2="${y}" class="g-grid"/><text x="28" y="${y+3}" class="g-axis" text-anchor="end">${v}%</text>`});
 subs.forEach((sub,k)=>{const a=syllabus[sub],d=a.filter((_,i)=>isDone(sub,i)).length,p=Math.round(d/a.length*100),x=34+slot*k+(slot-bw)/2,h=p*1.5;D+=d;T+=a.length;
  g+=`<rect x="${x}" y="40" width="${bw}" height="150" rx="10" class="g-track"/>${h?`<rect x="${x}" y="${190-h}" width="${bw}" height="${h}" rx="10" fill="url(#gbar)"><animate attributeName="height" from="0" to="${h}" dur=".7s"/><animate attributeName="y" from="190" to="${190-h}" dur=".7s"/></rect>`:''}<text x="${x+bw/2}" y="${Math.max(186-h,30)}" class="g-val" text-anchor="middle">${p}%</text><text x="${x+bw/2}" y="210" class="g-name" text-anchor="middle">${esc(SHORT[sub]||sub)}</text><text x="${x+bw/2}" y="225" class="g-axis" text-anchor="middle">${d}/${a.length}</text>`});
 $('#compGraph').innerHTML=`<svg viewBox="0 0 ${W} 235" role="img" aria-label="Syllabus completion by subject">${g}</svg>`;
 $('#gOverall').textContent=D+' / '+T+' chapters • '+Math.round(D/T*100)+'%';
}
function renderPicker(){
 const open=new Set($$('.tp-sub[open]').map(d=>d.dataset.sub));
 $('#tPicker').innerHTML=subs.map(sub=>{const a=syllabus[sub],n=a.filter((_,i)=>draft[K(sub,i)]).length;
  return `<details class="tp-sub" data-sub="${esc(sub)}" ${open.has(sub)?'open':''}><summary><span>${esc(sub)}</span><em class="${n?'on':''}">${n}/${a.length}</em></summary><div class="tp-actions"><button type="button" data-act="all">Select all</button><button type="button" data-act="pending">Only pending</button><button type="button" data-act="none">Clear</button></div><div class="tp-chips">${a.map((ch,i)=>`<label class="tp-chip ${isDone(sub,i)?'is-done':''}"><input type="checkbox" data-i="${i}" ${draft[K(sub,i)]?'checked':''}><span>${esc(ch)}</span>${isDone(sub,i)?'<b>✓</b>':''}</label>`).join('')}</div></details>`}).join('');
 $('#tCount').textContent=Object.values(draft).filter(Boolean).length+' chapters selected';
}
function renderList(){
 const box=$('#tList');
 if(!tests.length){box.innerHTML='<div class="empty-plan">No tests yet. Choose a date and the syllabus on the left, then save.</div>';return}
 box.innerHTML=tests.map(t=>{const by={};t.sel.forEach(k=>{const [s,i]=k.split('::');if(syllabus[s])(by[s]=by[s]||[]).push(+i)});
  let d=0,tot=0;const rows=Object.entries(by).map(([s,ix])=>{const dn=ix.filter(i=>isDone(s,i)).length;d+=dn;tot+=ix.length;return `<div class="tl-row"><span>${esc(SHORT[s]||s)}</span><div class="bar"><div class="fill" style="width:${Math.round(dn/ix.length*100)}%"></div></div><b>${dn}/${ix.length}</b></div>`}).join('');
  const p=tot?Math.round(d/tot*100):0,L=left(t.date),tag=L<0?'Passed':L===0?'Today':L===1?'Tomorrow':'In '+L+' days';
  return `<div class="tcard ${L<0?'past':L<=3?'soon':''}"><div class="tc-top"><div><b>${esc(t.name)}</b><small>${fmt(t.date)}</small></div><span class="pill">${tag}</span></div><div class="tc-big"><b>${p}%</b><span>of test syllabus complete<br><small>${d} of ${tot} chapters done</small></span></div>${rows}<button class="tdel" data-tdel="${t.id}">Delete test</button></div>`}).join('');
}
$('#tPicker').addEventListener('change',e=>{const d=e.target.closest('.tp-sub');if(d&&e.target.dataset.i!==undefined){draft[K(d.dataset.sub,e.target.dataset.i)]=e.target.checked;renderPicker()}});
$('#tPicker').addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b)return;const sub=b.closest('.tp-sub').dataset.sub;syllabus[sub].forEach((_,i)=>{draft[K(sub,i)]=b.dataset.act==='all'||(b.dataset.act==='pending'&&!isDone(sub,i))});renderPicker()});
$('#tList').addEventListener('click',e=>{const b=e.target.closest('[data-tdel]');if(!b)return;tests=tests.filter(t=>String(t.id)!==b.dataset.tdel);localStorage.setItem(LK,JSON.stringify(tests));renderList()});
$('#tSave').onclick=()=>{const name=$('#tName').value.trim(),date=$('#tDate').value,sel=Object.keys(draft).filter(k=>draft[k]);
 if(!name||!date||!sel.length){alert('Enter a test name, pick the test date and select at least one chapter.');return}
 tests.push({id:Date.now(),name,date,sel});tests.sort((a,b)=>a.date<b.date?-1:1);localStorage.setItem(LK,JSON.stringify(tests));
 const s=getS();s.events[date]=(s.events[date]?s.events[date]+' • ':'')+'📝 '+name;
 draft={};$('#tName').value='';$('#tDate').value='';save()};
const t0=new Date();$('#tDate').min=t0.getFullYear()+'-'+String(t0.getMonth()+1).padStart(2,'0')+'-'+String(t0.getDate()).padStart(2,'0');
window.cbseRefresh=()=>{renderGraph();renderPicker();renderList()};
};
